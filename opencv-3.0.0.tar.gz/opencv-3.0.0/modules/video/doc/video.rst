*********************
video. Video Analysis
*********************

.. toctree::
    :maxdepth: 2

    motion_analysis_and_object_tracking
