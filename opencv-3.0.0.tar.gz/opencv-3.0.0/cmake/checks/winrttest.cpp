#include <wrl/client.h>

int main(int, char**)
{
    return 0;
}
