package org.opencv.test.ml;

import org.opencv.ml.CvERTrees;
import org.opencv.test.OpenCVTestCase;

public class CvERTreesTest extends OpenCVTestCase {

    public void testCvERTrees() {
        new CvERTrees();
    }

    public void testTrainMatIntMat() {
        fail("Not yet implemented");
    }

    public void testTrainMatIntMatMat() {
        fail("Not yet implemented");
    }

    public void testTrainMatIntMatMatMat() {
        fail("Not yet implemented");
    }

    public void testTrainMatIntMatMatMatMat() {
        fail("Not yet implemented");
    }

    public void testTrainMatIntMatMatMatMatMat() {
        fail("Not yet implemented");
    }

    public void testTrainMatIntMatMatMatMatMatCvRTParams() {
        fail("Not yet implemented");
    }

}
