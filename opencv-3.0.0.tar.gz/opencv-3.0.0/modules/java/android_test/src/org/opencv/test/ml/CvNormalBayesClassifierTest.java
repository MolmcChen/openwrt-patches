package org.opencv.test.ml;

import org.opencv.ml.CvNormalBayesClassifier;
import org.opencv.test.OpenCVTestCase;

public class CvNormalBayesClassifierTest extends OpenCVTestCase {

    public void testClear() {
        fail("Not yet implemented");
    }

    public void testCvNormalBayesClassifier() {
        new CvNormalBayesClassifier();
    }

    public void testCvNormalBayesClassifierMatMat() {
        fail("Not yet implemented");
    }

    public void testCvNormalBayesClassifierMatMatMat() {
        fail("Not yet implemented");
    }

    public void testCvNormalBayesClassifierMatMatMatMat() {
        fail("Not yet implemented");
    }

    public void testPredictMat() {
        fail("Not yet implemented");
    }

    public void testPredictMatMat() {
        fail("Not yet implemented");
    }

    public void testTrainMatMat() {
        fail("Not yet implemented");
    }

    public void testTrainMatMatMat() {
        fail("Not yet implemented");
    }

    public void testTrainMatMatMatMat() {
        fail("Not yet implemented");
    }

    public void testTrainMatMatMatMatBoolean() {
        fail("Not yet implemented");
    }

}
