package org.opencv.test.features2d;

import org.opencv.test.OpenCVTestCase;

public class OneWayGenericDescriptorMatcherTest extends OpenCVTestCase {

    public void testAdd() {
        fail("Not yet implemented");
    }

    public void testClassifyMatListOfKeyPointMatListOfKeyPoint() {
        fail("Not yet implemented");
    }

    public void testClassifyMatListOfKeyPoint() {
        fail("Not yet implemented");
    }

    public void testClear() {
        fail("Not yet implemented");
    }

    public void testCloneBoolean() {
        fail("Not yet implemented");
    }

    public void testClone() {
        fail("Not yet implemented");
    }

    public void testCreate() {
        fail("Not yet implemented");
    }

    public void testEmpty() {
        fail("Not yet implemented");
    }

    public void testGetTrainImages() {
        fail("Not yet implemented");
    }

    public void testGetTrainKeypoints() {
        fail("Not yet implemented");
    }

    public void testIsMaskSupported() {
        fail("Not yet implemented");
    }

    public void testKnnMatchMatListOfKeyPointMatListOfKeyPointListOfListOfDMatchIntMatBoolean() {
        fail("Not yet implemented");
    }

    public void testKnnMatchMatListOfKeyPointMatListOfKeyPointListOfListOfDMatchIntMat() {
        fail("Not yet implemented");
    }

    public void testKnnMatchMatListOfKeyPointMatListOfKeyPointListOfListOfDMatchInt() {
        fail("Not yet implemented");
    }

    public void testKnnMatchMatListOfKeyPointListOfListOfDMatchIntListOfMatBoolean() {
        fail("Not yet implemented");
    }

    public void testKnnMatchMatListOfKeyPointListOfListOfDMatchIntListOfMat() {
        fail("Not yet implemented");
    }

    public void testKnnMatchMatListOfKeyPointListOfListOfDMatchInt() {
        fail("Not yet implemented");
    }

    public void testMatchMatListOfKeyPointMatListOfKeyPointListOfDMatchMat() {
        fail("Not yet implemented");
    }

    public void testMatchMatListOfKeyPointMatListOfKeyPointListOfDMatch() {
        fail("Not yet implemented");
    }

    public void testMatchMatListOfKeyPointListOfDMatchListOfMat() {
        fail("Not yet implemented");
    }

    public void testMatchMatListOfKeyPointListOfDMatch() {
        fail("Not yet implemented");
    }

    public void testRadiusMatchMatListOfKeyPointMatListOfKeyPointListOfListOfDMatchFloatMatBoolean() {
        fail("Not yet implemented");
    }

    public void testRadiusMatchMatListOfKeyPointMatListOfKeyPointListOfListOfDMatchFloatMat() {
        fail("Not yet implemented");
    }

    public void testRadiusMatchMatListOfKeyPointMatListOfKeyPointListOfListOfDMatchFloat() {
        fail("Not yet implemented");
    }

    public void testRadiusMatchMatListOfKeyPointListOfListOfDMatchFloatListOfMatBoolean() {
        fail("Not yet implemented");
    }

    public void testRadiusMatchMatListOfKeyPointListOfListOfDMatchFloatListOfMat() {
        fail("Not yet implemented");
    }

    public void testRadiusMatchMatListOfKeyPointListOfListOfDMatchFloat() {
        fail("Not yet implemented");
    }

    public void testRead() {
        fail("Not yet implemented");
    }

    public void testTrain() {
        fail("Not yet implemented");
    }

    public void testWrite() {
        fail("Not yet implemented");
    }

}
