package org.opencv.test.ml;

import org.opencv.ml.CvKNearest;
import org.opencv.test.OpenCVTestCase;

public class CvKNearestTest extends OpenCVTestCase {

    public void testCvKNearest() {
        new CvKNearest();
    }

    public void testCvKNearestMatMat() {
        fail("Not yet implemented");
    }

    public void testCvKNearestMatMatMat() {
        fail("Not yet implemented");
    }

    public void testCvKNearestMatMatMatBoolean() {
        fail("Not yet implemented");
    }

    public void testCvKNearestMatMatMatBooleanInt() {
        fail("Not yet implemented");
    }

    public void testFind_nearest() {
        fail("Not yet implemented");
    }

    public void testTrainMatMat() {
        fail("Not yet implemented");
    }

    public void testTrainMatMatMat() {
        fail("Not yet implemented");
    }

    public void testTrainMatMatMatBoolean() {
        fail("Not yet implemented");
    }

    public void testTrainMatMatMatBooleanInt() {
        fail("Not yet implemented");
    }

    public void testTrainMatMatMatBooleanIntBoolean() {
        fail("Not yet implemented");
    }

}
