***************************************************
cudacodec. CUDA-accelerated Video Encoding/Decoding
***************************************************

.. toctree::
    :maxdepth: 1

    videodec
    videoenc
